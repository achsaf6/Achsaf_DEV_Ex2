import styles from "./page.module.css";

export default function Demos() {
  return (
    <main>
      <h1 className={styles.hey}>Hey</h1>
    </main>
  );
}
