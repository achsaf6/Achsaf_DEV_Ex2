export interface ContactFormResponse {
  success: boolean;
  message: string;
}
